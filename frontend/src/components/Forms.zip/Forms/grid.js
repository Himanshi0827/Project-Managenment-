import React from 'react'
import Button from '@mui/material/Button';


function Grid() {
  return (
    <div>
    <Button variant="contained">New Form</Button>
    </div>
  )
}

export default Grid
