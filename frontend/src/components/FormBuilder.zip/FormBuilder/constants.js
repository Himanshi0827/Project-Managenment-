export const formEl = [
  { label: "Text", value: "text" },
  { label: "Textarea", value: "textarea" },
  { label: "Number", value: "number" },
  { label: "Radio", value: "radio" },
  { label: "Checkbox", value: "checkbox" }, // Add checkbox type
  // { label: "Date", value: "date" },
  // { label: "Time", value: "time" },
  { label: "Upload File", value: "uploadfile" },
];
